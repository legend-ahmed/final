﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Speech.Synthesis;

namespace my_project4
{
    public partial class trans_sound : Form
    {
        SpeechSynthesizer x = new SpeechSynthesizer();

        DBConnection m = new DBConnection();
        public trans_sound()
        {
            InitializeComponent();
        }
             
                 

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            if (txtwa.Text.Trim().Length == 0)
            {
                x.SpeakAsync(" must enter the word ");
                MessageBox.Show("  \tيجب أدخال الكلمه \n must enter the word", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
             errorProvider1.Dispose();//this function to remove control from form   إزلة شكل أداة التنبية من النموذج
            if (txtwa.Text.Trim().Length > 0)
            {
                txt_we.Text = m.DictionaryWord("select English  from tbl_dictionary where Arabic='" + txtwa.Text + "'");
                if (txt_we.Text.Trim().Length > 0)
                    x.SpeakAsync(txt_we.Text);
                else
                {
                    x.SpeakAsync("This word is not found");
                    MessageBox.Show("  \tهذة الكلمه غيرموجوده \n This word is not found", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    errorProvider1.SetError(txtwa, " هذة الكلمه غيرموجوده");
                }
            }
            else
            {
                x.SpeakAsync("Please Fill Arabic word correct");
                errorProvider1.SetError(txtwa, "يجب ادخال كلمه ");
                txtwa.Focus();
            }
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            errorProvider1.Dispose();
            txt_we.Clear();
            txtwa.Clear();
            txtwa.Focus();
        }

        
    }
}
