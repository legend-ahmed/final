﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using TMVoiceTOText;
using System.Speech.Recognition;
namespace my_project4
{
    class DBConnection
    {

        SqlConnection SQLCON = new SqlConnection("Data Source=.\\SQLEXPRESS;AttachDbFilename=|DataDirectory|\\databace.mdf;Integrated Security=True;User Instance=True");
         
        SqlCommand SQLCOM = new SqlCommand();
        SqlDataReader SQLRead;



        public bool ADDWord(string q)
        {
            bool b = false;
            try
            {
                SQLCON.Open();
                SQLCOM.Connection = SQLCON;
                SQLCOM.CommandText = q;//**************
                if (SQLCOM.ExecuteNonQuery() > 0)//********
                    b = true;

                SQLCON.Close();
            }
            catch (Exception ex) { }
            return b;
        }


        public string DictionaryWord(string q)
        {
            string b = null;
            SQLCON.Open();
            SQLCOM.Connection = SQLCON;
            SQLCOM.CommandText = q;
            SQLRead = SQLCOM.ExecuteReader();

            if(SQLRead.Read()==true)
                b = SQLRead.GetValue(0).ToString();//**
            SQLRead.Close();
            SQLCON.Close();
            return b;
        }

        public DataTable GetWords(string q)
        {
            DataTable d = new DataTable("Table");

            SQLCON.Open();
            SQLCOM.Connection = SQLCON;
            SQLCOM.CommandText = q;
            SqlDataAdapter dataa = new SqlDataAdapter(SQLCOM);
            dataa.Fill(d);

            SQLCON.Close();
            return d;
        }
        ConvertVoiceTOText c;
          //ConvertVoiceTOText bbbb = new ConvertVoiceTOText();
        public void AddWordFromDictionary(string q)
        {
            try
            {
                c = new ConvertVoiceTOText();
                SQLCON.Open();
                SQLCOM.Connection = SQLCON;
                SQLCOM.CommandText = q;
                SQLRead = SQLCOM.ExecuteReader();

                while (SQLRead.Read() == true)
                {
                    c.VoiceToText(SQLRead.GetValue(0).ToString());
                }

                SQLRead.Close();
                SQLCON.Close();
            }
            catch (Exception ex) { }
        }
    }
}

