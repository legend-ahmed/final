﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Speech.Synthesis;

namespace my_project4
{
    public partial class trans_ar : Form
    {
        DBConnection m = new DBConnection();
        SpeechSynthesizer x = new SpeechSynthesizer();
        public trans_ar()
        {
            InitializeComponent();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {

        }



        private void trans_ar_Load(object sender, EventArgs e)
        {

        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            if (txtwa.Text.Trim().Length == 0)
            {
                x.SpeakAsync(" must enter the word ");
                MessageBox.Show("  \tيجب أدخال الكلمه  \n must enter the word", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            if (txtwa.Text.Trim().Length > 0)
            {
                txt_we.Text = m.DictionaryWord("select English  from tbl_dictionary where Arabic='" + txtwa.Text + "'");
                
                 
                if (m.GetWords("select * from tbl_dictionary where Arabic='" + txtwa.Text + "'").Rows.Count == 0 && txtwa.Text.Trim().Length > 0)
                {
                    x.SpeakAsync("  this word  is  not found  ");
                    MessageBox.Show(" \tالكلمه غير موجوده في القاموس\n this word  is  not found", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }

        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            txt_we.Clear();
            txtwa.Clear();
            txtwa.Focus();
        }

    }
}


        
 
      
