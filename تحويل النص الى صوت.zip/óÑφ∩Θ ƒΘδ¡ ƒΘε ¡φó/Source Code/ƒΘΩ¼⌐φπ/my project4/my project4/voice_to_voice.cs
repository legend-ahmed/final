﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Voice;

namespace my_project4
{
    public partial class voice_to_voice : Form
    {
        public int o = 0;
        #region variables
        private Socket r;
        private Thread t;
        private bool connected = false;
         
               
        private WaveOutPlayer m_Player;
        private WaveInRecorder m_Recorder;
        private FifoStream m_Fifo = new FifoStream();

        private byte[] m_PlayBuffer;
        private byte[] m_RecBuffer;

        #endregion

        public voice_to_voice()
        {
            InitializeComponent();
            r = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            t = new Thread(new ThreadStart(Voice_In));
        }
        private void Voice_In()
        {
            try
            {
                byte[] br;
                r.Bind(new IPEndPoint(IPAddress.Any, 9800));
                while (true)
                {
                    br = new byte[16384];
                    r.Receive(br);
                    m_Fifo.Write(br, 0, br.Length);
                }
            }
            catch (Exception EX) { }
        }
        private void Voice_Out(IntPtr data, int size)
        {
            try
            {
                //for Recorder
                if (m_RecBuffer == null || m_RecBuffer.Length < size)
                    m_RecBuffer = new byte[size];
                System.Runtime.InteropServices.Marshal.Copy(data, m_RecBuffer, 0, size);
                //Microphone ==> data ==> m_RecBuffer ==> m_Fifo
                r.SendTo(m_RecBuffer, new IPEndPoint(IPAddress.Parse("200.200.200.2"), 9900));
            }
            catch (Exception ex) { }
        }
        private void Start()
        {
            Stop();
            try
            {
                WaveFormat fmt = new WaveFormat(44100, 16, 2);
                m_Player = new WaveOutPlayer(-1, fmt, 16384, 3, new BufferFillEventHandler(Filler));
                m_Recorder = new WaveInRecorder(-1, fmt, 16384, 3, new BufferDoneEventHandler(Voice_Out));
            }
            catch
            {
                Stop();
                throw;
            }
        }

        private void Stop()
        {
            if (m_Player != null)
                try
                {
                    m_Player.Dispose();
                }
                finally
                {
                    m_Player = null;
                }
            if (m_Recorder != null)
                try
                {
                    m_Recorder.Dispose();
                }
                finally
                {
                    m_Recorder = null;
                }
            m_Fifo.Flush(); // clear all pending data
        }

        private void Filler(IntPtr data, int size)
        {
            if (m_PlayBuffer == null || m_PlayBuffer.Length < size)
                m_PlayBuffer = new byte[size];
            if (m_Fifo.Length >= size)
                m_Fifo.Read(m_PlayBuffer, 0, size);
            else
                for (int i = 0; i < m_PlayBuffer.Length; i++)
                    m_PlayBuffer[i] = 0;
            System.Runtime.InteropServices.Marshal.Copy(m_PlayBuffer, 0, data, size);

        }



        private void btn_start_Click(object sender, EventArgs e)
        {
            if (connected == false)
            {
                t.Start();
                connected = true;
            }

            Start();
        }

        private void voice_to_voice_FormClosing(object sender, FormClosingEventArgs e)
        {
            t.Abort();
            r.Close();
            Stop();
        }

        private void btn_stop_Click(object sender, EventArgs e)
        {
            Stop();
        }

        private void voice_to_voice_Load(object sender, EventArgs e)
        {
            
            o = 0;
            try
            {
                if (o == 0)
                {
                    Socket clientSock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    byte[] text = Encoding.UTF8.GetBytes("ddd");
                    clientSock.Connect(cmb_ipaddresses.Text, 2000);
                    clientSock.Send(text);
                    clientSock.Close();
                    o = 1;

                }


            }
            catch (Exception ex) { };
        }

        
        
        
    }
}
