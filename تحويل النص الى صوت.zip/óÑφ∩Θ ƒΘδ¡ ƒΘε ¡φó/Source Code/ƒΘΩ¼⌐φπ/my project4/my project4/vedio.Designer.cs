﻿namespace my_project4
{
    partial class vedio
    {
        
       

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.IP_textBox = new System.Windows.Forms.TextBox();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.picture_comming = new System.Windows.Forms.PictureBox();
            this.picCapture = new System.Windows.Forms.PictureBox();
            this.device_number_textBox = new System.Windows.Forms.TextBox();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.cmb_ipaddresses = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.picture_comming)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCapture)).BeginInit();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button2.Location = new System.Drawing.Point(491, 228);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 23);
            this.button2.TabIndex = 26;
            this.button2.Text = " أرسال فديو";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button1.Location = new System.Drawing.Point(491, 266);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 23);
            this.button1.TabIndex = 25;
            this.button1.Text = " إستقبال";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // IP_textBox
            // 
            this.IP_textBox.Location = new System.Drawing.Point(238, 90);
            this.IP_textBox.Name = "IP_textBox";
            this.IP_textBox.Size = new System.Drawing.Size(161, 20);
            this.IP_textBox.TabIndex = 23;
            this.IP_textBox.Text = "127.0.0.1";
            this.IP_textBox.Visible = false;
            // 
            // btnStop
            // 
            this.btnStop.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnStop.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnStop.Location = new System.Drawing.Point(215, 394);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(112, 32);
            this.btnStop.TabIndex = 21;
            this.btnStop.Text = " ايقاف الكيمراء";
            // 
            // btnStart
            // 
            this.btnStart.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnStart.Location = new System.Drawing.Point(70, 394);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(112, 32);
            this.btnStart.TabIndex = 20;
            this.btnStart.Text = "تشغيل الكيمراء";
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // picture_comming
            // 
            this.picture_comming.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picture_comming.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picture_comming.Location = new System.Drawing.Point(12, 143);
            this.picture_comming.Name = "picture_comming";
            this.picture_comming.Size = new System.Drawing.Size(387, 232);
            this.picture_comming.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picture_comming.TabIndex = 22;
            this.picture_comming.TabStop = false;
            // 
            // picCapture
            // 
            this.picCapture.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picCapture.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picCapture.Location = new System.Drawing.Point(38, 22);
            this.picCapture.Name = "picCapture";
            this.picCapture.Size = new System.Drawing.Size(181, 105);
            this.picCapture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picCapture.TabIndex = 19;
            this.picCapture.TabStop = false;
            // 
            // device_number_textBox
            // 
            this.device_number_textBox.Location = new System.Drawing.Point(236, 48);
            this.device_number_textBox.Name = "device_number_textBox";
            this.device_number_textBox.Size = new System.Drawing.Size(143, 20);
            this.device_number_textBox.TabIndex = 28;
            this.device_number_textBox.Text = "0";
            this.device_number_textBox.Visible = false;
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // cmb_ipaddresses
            // 
            this.cmb_ipaddresses.BackColor = System.Drawing.Color.LightBlue;
            this.cmb_ipaddresses.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.cmb_ipaddresses.FormattingEnabled = true;
            this.cmb_ipaddresses.Location = new System.Drawing.Point(460, 67);
            this.cmb_ipaddresses.Name = "cmb_ipaddresses";
            this.cmb_ipaddresses.Size = new System.Drawing.Size(153, 138);
            this.cmb_ipaddresses.TabIndex = 29;
            // 
            // vedio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::my_project4.Properties.Resources.خلفية_23;
            this.ClientSize = new System.Drawing.Size(638, 438);
            this.Controls.Add(this.cmb_ipaddresses);
            this.Controls.Add(this.device_number_textBox);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.IP_textBox);
            this.Controls.Add(this.picture_comming);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.picCapture);
            this.Name = "vedio";
            this.Text = "vedio";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.vedio_FormClosing_1);
            ((System.ComponentModel.ISupportInitialize)(this.picture_comming)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCapture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox device_number_textBox;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.ComboBox cmb_ipaddresses;

        

        
    }
}