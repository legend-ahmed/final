﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Speech.Synthesis;
namespace my_project4
{
    public partial class Form1 : Form
    {
        SpeechSynthesizer x = new SpeechSynthesizer();
         
        DBConnection m = new DBConnection();
        public Form1()
        {
            InitializeComponent();
        }

      
        
        private void CText()
        {
            txt_we.Clear();
            txtwa.Clear();
            txt_we.Focus();
        }

              private void txt_we_TextChanged_2(object sender, EventArgs e)
        {
            err.Dispose();
            if (txt_we.Text.Trim().Length > 0 && txtwa.Text.Trim().Length == 0)
            {
                err.SetError(txtwa, "يجب إدخال الكلمة");
            }

        }

        private void txtwa_TextChanged_2(object sender, EventArgs e)
        {
            err.Dispose();
            if (txt_we.Text.Trim().Length == 0 && txtwa.Text.Trim().Length > 0)
            {
                err.SetError(txt_we, "يجب إدخال الكلمة");
            }

        }

           
        private void simpleButton1_Click(object sender, EventArgs e)
        {
            CText();
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            err.Dispose();
            if (txt_we.Text.Trim().Length == 0 && txtwa.Text.Trim().Length == 0)
            {
                x.SpeakAsync("must insert the word in box"); err.SetError(txt_we, "يجب إدخال الكلمة");
                err.SetError(txtwa, "يجب إدخال الكلمة");
            }
            else if (txt_we.Text.Trim().Length > 0 && txtwa.Text.Trim().Length == 0)
            {
                x.SpeakAsync("must insert the word in box"); err.SetError(txtwa, "يجب إدخال الكلمة");
            }
            else if (txt_we.Text.Trim().Length == 0 && txtwa.Text.Trim().Length > 0)
            {
                x.SpeakAsync("must insert the word in box"); err.SetError(txt_we, "يجب إدخال الكلمة");

            }
            else if (txt_we.Text.Trim().Length > 0 && txtwa.Text.Trim().Length > 0)
            {
                if (m.GetWords("select * from tbl_dictionary where English='" + txt_we.Text + "'").Rows.Count == 0)
                {
                    if (m.ADDWord("insert into tbl_dictionary (English,Arabic) values ('" + txt_we.Text + "','" + txtwa.Text + "')") == true)
                    {
                        x.SpeakAsync("This word   is adding in to dictionary");
                        MessageBox.Show(" \t تم أضافة كلمة بنجاح   \n  This word   is adding in to dictionary ", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        CText();
                    }
                    else
                    {
                        x.SpeakAsync("This word   is  not adding ");
                        MessageBox.Show("الكلمة لم تضاف", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    x.SpeakAsync("This word   is  found ");
                    MessageBox.Show("\t  الكلمة مضافة من سابق \n This word   is  found", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

         

        
    }
}
