﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;

namespace my_project4
{
    public partial class main : Form
    {
        Thread Thread1; 
        int flag = 0;
        string GetData = "";
        public delegate void MyDelegate();
        public static ManualResetEvent ActiveThread = new ManualResetEvent(false);
        public main()
        {
            InitializeComponent();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 n = new Form1();
            n.Show();
            
        }

       
        private void الصفحةالرئيسيةToolStripMenuItem_Click(object sender, EventArgs e)
        {

            this.Hide();
        }

        

        private void barButtonItem1_ItemPress(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form1 n = new Form1();
            n.MdiParent = this;
            n.Show();
        }

        private void barButtonItem2_ItemPress(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            client n = new client();
            n.MdiParent = this;
            n.Show();
        }

        private void barButtonItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }

        private void barButtonItem3_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            trans_ar a = new trans_ar();
            a.MdiParent = this;
            a.Show();
        }

        private void barButtonItem4_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            trans_e o = new trans_e();
            o.MdiParent = this;
            o.Show();
        }

        private void barButtonItem5_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            trans_sound s = new  trans_sound();
            s.MdiParent = this;
            s.Show();

        }
 
        private void btn_help_ItemPress(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

            try
            {
                Process.Start(Application.StartupPath + "\\help1.chm");
            }
            catch (Exception ex) { }                                

        }

        private void main_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F1)
                Process.Start(Application.StartupPath + "\\help1.chm");
            else if (e.KeyCode == Keys.F2)
                barButtonItem1_ItemPress(null, null);
            else if (e.KeyCode == Keys.F3)
                barButtonItem3_ItemClick(null, null);
            else if (e.KeyCode == Keys.F4)
                barButtonItem4_ItemClick(null, null);
            else if (e.KeyCode == Keys.F5)
                barButtonItem5_ItemClick(null, null);

            
        }

        private void barButtonItem6_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }

        private void barButtonItem3_ItemClick_1(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }

        private void btu_com_vtot_ItemPress(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
          comunction_vo z = new  comunction_vo();
            z.MdiParent = this;
            z.Show();

        }

        private void but_vtov_ItemPress(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            vedio o = new vedio();
            o.MdiParent = this;
            o.Show();


        }

        private void but_voice_to_t_ItemPress(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
           frm_VoiceToText f = new  frm_VoiceToText();
            f.MdiParent = this;
            f.Show(); 
        }

        private void main_Load(object sender, EventArgs e)
        {
            TM f = new TM();
            f.computers_name(cmb_ipaddresses);
            Thread1 = new Thread(new ThreadStart(MethodListening));
            Thread1.Start();
        }

        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }

        private void btn_help_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }

        public void MethodListening()
        {
            byte[] Databytes = new Byte[1024];
            IPEndPoint InitIp = new IPEndPoint(IPAddress.Any, 2000);
            Socket ListenerObject = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                ListenerObject.Bind(InitIp);
                ListenerObject.Listen(50);
                while (true)
                {
                    ActiveThread.Reset();
                    ListenerObject.BeginAccept(new AsyncCallback(AcceptCallback), ListenerObject);
                    ActiveThread.WaitOne();
                }
            }
            catch (Exception ex) { }
        }
        public class StateObject
        {

            public Socket WorkSocket = null;
            public const int BufferSize = 1024;
            public byte[] buffer = new byte[BufferSize];
        }
        public void AcceptCallback(IAsyncResult ar)
        {
            ActiveThread.Set();
            Socket ListenerObject = (Socket)ar.AsyncState; Socket handler = ListenerObject.EndAccept
            (ar);
            StateObject state = new StateObject();
            state.WorkSocket = handler; handler.BeginReceive(state.buffer, 0,
            StateObject.BufferSize, 0, new AsyncCallback(ReadCallback), state); flag = 0;
        }
        public void ReadCallback(IAsyncResult ar)
        {
            int fileNameLen = 1; String content = String.Empty; StateObject state =
            (StateObject)ar.AsyncState; Socket handler = state.WorkSocket; int bytesRead =
            handler.EndReceive(ar);
            if (bytesRead > 0)
            {
                try
                {
                    GetData = Encoding.UTF8.GetString(state.buffer, 0, bytesRead);
                    Invoke(new MyDelegate(LabelWriter));
                }
                catch (Exception ex) { };
            }

        }
        public void LabelWriter()
        {
            //textBox1.AppendText(GetData);
            if (GetData == "aaa")
            {
                client n = new client();
                    n.MdiParent = this;
                    n.Show();
                    
               
            }
            else
            {
                if (GetData == "bbb")
                {
                    comunction_vo n = new comunction_vo();
                    n.MdiParent = this;
                    n.Show();

                }
                else
                {
                    if (GetData == "ccc")
                    {
                        voice_to_voice n = new voice_to_voice();
                        n.MdiParent = this;
                        n.Show();

                    }  
                }
            }


        }

        private void barButtonItem8_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            about_us mm = new about_us();
            mm.MdiParent = this;
            mm.Show();
        }

        private void but_vtov_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }

        private void barButtonItem6_ItemClick_1(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            voice_to_voice k = new voice_to_voice();
            k.MdiParent = this;
            k.Show();
                    
        }

      
    }
}
