﻿namespace my_project4
{
    partial class voice_to_voice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_start = new DevExpress.XtraEditors.SimpleButton();
            this.btn_stop = new DevExpress.XtraEditors.SimpleButton();
            this.cmb_ipaddresses = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_start
            // 
            this.btn_start.Location = new System.Drawing.Point(426, 62);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(99, 34);
            this.btn_start.TabIndex = 0;
            this.btn_start.Text = "أبداء  ";
            this.btn_start.Click += new System.EventHandler(this.btn_start_Click);
            // 
            // btn_stop
            // 
            this.btn_stop.Location = new System.Drawing.Point(426, 131);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(99, 34);
            this.btn_stop.TabIndex = 1;
            this.btn_stop.Text = "أيقاف  ";
            this.btn_stop.Click += new System.EventHandler(this.btn_stop_Click);
            // 
            // cmb_ipaddresses
            // 
            this.cmb_ipaddresses.BackColor = System.Drawing.Color.LightBlue;
            this.cmb_ipaddresses.DropDownStyle = System.Windows.Forms.ComboBoxStyle.Simple;
            this.cmb_ipaddresses.FormattingEnabled = true;
            this.cmb_ipaddresses.Location = new System.Drawing.Point(16, 195);
            this.cmb_ipaddresses.Name = "cmb_ipaddresses";
            this.cmb_ipaddresses.Size = new System.Drawing.Size(153, 138);
            this.cmb_ipaddresses.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.Image = global::my_project4.Properties.Resources.خلفية_2;
            this.label2.Location = new System.Drawing.Point(12, 168);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(157, 24);
            this.label2.TabIndex = 23;
            this.label2.Text = "تحديد الجهاز على الشبكه";
            // 
            // voice_to_voice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::my_project4.Properties.Resources.خلفية_22;
            this.ClientSize = new System.Drawing.Size(537, 385);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmb_ipaddresses);
            this.Controls.Add(this.btn_stop);
            this.Controls.Add(this.btn_start);
            this.Name = "voice_to_voice";
            this.Text = "voice_to_voice";
            this.Load += new System.EventHandler(this.voice_to_voice_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.voice_to_voice_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.SimpleButton btn_start;
        private DevExpress.XtraEditors.SimpleButton btn_stop;
        private System.Windows.Forms.ComboBox cmb_ipaddresses;
        private System.Windows.Forms.Label label2;
    }
}