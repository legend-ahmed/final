﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Speech.Synthesis;
using System.Threading;
using System.IO;
using TMVoiceTOText;
namespace my_project4
{
    public partial class frm_VoiceToText : Form
    {
        public int o = 0;
        SpeechSynthesizer x = new SpeechSynthesizer();
        Thread Thread1; int flag = 0;
        string GetData = "";
        string n = null;
        public delegate void MyDelegate();
       
        public static ManualResetEvent ActiveThread = new ManualResetEvent(false);
        DBConnection m = new DBConnection();
        DBConnection db = new DBConnection();
        ConvertVoiceTOText c = new ConvertVoiceTOText();
       
        public frm_VoiceToText()
        {
            InitializeComponent();
          
           
        }

        private void frm_VoiceToText_Load(object sender, EventArgs e)
        {
            //getword();
            TM sa = new TM();
            sa.computers_name(cmb_ipaddresses);
           
            Thread1 = new Thread(new ThreadStart(MethodListening));
            Thread1.Start();

           
        }
       
        private void timer1_Tick(object sender, EventArgs e)
        {
             

                if (n != ConvertVoiceTOText.t)
                {


                    try
                    {
                        n = ConvertVoiceTOText.t;
                        textBox1.AppendText(ConvertVoiceTOText.t + " ");

                    }
                    catch (Exception ex) { }
                }
                 
        }
        Socket ListenerObject;
        public void MethodListening()
        {
            byte[] Databytes = new Byte[1024];
            IPEndPoint InitIp = new IPEndPoint(IPAddress.Any, 9050);
             ListenerObject = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                ListenerObject.Bind(InitIp);
                ListenerObject.Listen(50);
                while (true)
                {
                    ActiveThread.Reset();
                    ListenerObject.BeginAccept(new AsyncCallback(AcceptCallback), ListenerObject);
                    ActiveThread.WaitOne();
                }
            }
            catch (Exception ex) { }
        }
        public class StateObject
        {


            public Socket WorkSocket = null;
            public const int BufferSize = 1024;
            public byte[] buffer = new byte[BufferSize];
        }
        Socket ListenerObject1, handler;
        public void AcceptCallback(IAsyncResult ar)
        {
            try
            {
                ActiveThread.Set();
                ListenerObject1 = (Socket)ar.AsyncState;
                handler = ListenerObject.EndAccept(ar);
                StateObject state = new StateObject();
                state.WorkSocket = handler; handler.BeginReceive(state.buffer, 0,
                StateObject.BufferSize, 0, new AsyncCallback(ReadCallback), state); flag = 0;
            }
            catch (Exception ex) { };
        }
        public void ReadCallback(IAsyncResult ar)
        {
            int fileNameLen = 1; String content = String.Empty; StateObject state =
            (StateObject)ar.AsyncState; Socket handler = state.WorkSocket; int bytesRead =
            handler.EndReceive(ar);
            if (bytesRead > 0)
            {
                GetData = Encoding.UTF8.GetString(state.buffer, 0, bytesRead);
                Invoke(new MyDelegate(LabelWriter));
            }
        }
        public void LabelWriter()
        {
            textBox1.AppendText(GetData);
            
        }

        private void btn_send_Click(object sender, EventArgs e)
        {
            
            try
            {
                Socket clientSock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                byte[] text = Encoding.UTF8.GetBytes(textBox1.Text.ToString());
                clientSock.Connect(cmb_ipaddresses.Text, 9050);
                clientSock.Send(text);
                clientSock.Close();
            }
            catch (Exception ex) { };
        }

        private void frm_VoiceToText_FormClosing(object sender, FormClosingEventArgs e)
        {
            o = 0;
        }

        private void frm_VoiceToText_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                Thread1.Abort();
                ListenerObject.Close();
                ListenerObject1.Close();
                handler.Close();
            }
            catch (Exception ex) { };
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            try
            {
                if (o == 0)
                {
                    Socket clientSock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    byte[] text = Encoding.UTF8.GetBytes("ccc");
                    clientSock.Connect(cmb_ipaddresses.Text, 2000);
                    clientSock.Send(text);
                    clientSock.Close();
                    o = 1;

                }


            }
            catch (Exception ex) { };
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.Focus();
        }


      

    }
}
