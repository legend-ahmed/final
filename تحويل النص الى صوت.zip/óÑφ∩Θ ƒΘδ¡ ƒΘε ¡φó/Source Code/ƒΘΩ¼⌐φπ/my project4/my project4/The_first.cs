﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace my_project4
{
    public partial class The_first : Form
    {
        int i = 0;
        public The_first()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (i == 100)
            {
                timer1.Enabled = false;
                main f = new main();
                f.Show();
                this.Hide();
                i = 0;
            }
            else
            {
                progressBar1.Value = i;
                lb_count.Text = i + "%";

            }

            i += 1;
        }

        private void The_first_Load(object sender, EventArgs e)
        {

        }
    }
}
