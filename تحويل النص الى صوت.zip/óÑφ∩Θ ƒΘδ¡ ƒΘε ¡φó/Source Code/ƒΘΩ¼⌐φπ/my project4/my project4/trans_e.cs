﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Speech.Synthesis;
namespace my_project4
{
    public partial class trans_e : Form
    {
        SpeechSynthesizer x = new SpeechSynthesizer();
        DBConnection m = new DBConnection();
        public trans_e()
        {
            InitializeComponent();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            if (txt_we.Text.Trim().Length == 0)
            {
                x.SpeakAsync(" must enter the word ");
                MessageBox.Show("  \tيجب أدخال الكلمه \n must enter the word", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            if (txt_we.Text.Trim().Length > 0)
            {
                txtwa.Text = m.DictionaryWord("select Arabic  from tbl_dictionary where English='" + txt_we.Text + "'");

                if
                  (m.GetWords("select * from tbl_dictionary where English='" + txt_we.Text + "'").Rows.Count == 0 && txt_we.Text.Trim().Length > 0)
                {
                    x.SpeakAsync(" this word is not found ");
                    MessageBox.Show(" \t الكلمه غير موجوده في القاموس\n this word is not found", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            txt_we.Clear();
            txtwa.Clear();
            txt_we.Focus();
        }
    }
}
