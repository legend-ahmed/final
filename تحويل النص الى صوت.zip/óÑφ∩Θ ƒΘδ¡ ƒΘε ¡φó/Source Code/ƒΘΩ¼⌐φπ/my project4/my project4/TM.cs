﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.IO;
using System.DirectoryServices;
namespace my_project4
{
    class TM
    {
        public void computers_name(ComboBox CMB)
        {
            //CMB.Items.Insert(0, "");
            DirectoryEntry childEntry1 = new DirectoryEntry();
            DirectoryEntry ParentEntry1 = new DirectoryEntry();
            byte c = 1;
            try
            {

                ParentEntry1.Path = "WinNT:";
                foreach (DirectoryEntry childEntry in ParentEntry1.Children)
                {
                    if (childEntry.SchemaClassName == "Domain")
                    {
                        DirectoryEntry SubChildEntry11 = new DirectoryEntry();
                        DirectoryEntry SubParentEntry1 = new DirectoryEntry();

                        SubParentEntry1.Path = "WinNT://" + childEntry.Name;
                        foreach (DirectoryEntry SubChildEntry in SubParentEntry1.Children)
                        {
                            if (SubChildEntry.SchemaClassName == "Computer")
                            {
                                IPAddress[] addresslist = Dns.GetHostAddresses(SubChildEntry.Name);
                                foreach (IPAddress theaddress in addresslist)
                                {

                                    int i = 0;
                                    if (c % 2 == 0)
                                    {
                                        CMB.Items.Add(SubChildEntry.Name.ToString());
                                        i += 1;
                                    }
                                    c += 1;
                                }

                            }

                        }

                    }
                }
            }
            catch (Exception ex) { ParentEntry1 = null; }
        }
    }
}
