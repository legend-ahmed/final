﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Speech.Synthesis;
using System.Threading;
using System.IO;
namespace my_project4
{

    public partial class client : Form
    {
     
        SpeechSynthesizer x = new SpeechSynthesizer();
        Thread Thread1; int flag = 0;
        string GetData = "";
        public delegate void MyDelegate();
        public int i = 0;
        public static ManualResetEvent ActiveThread = new ManualResetEvent(false);
        DBConnection m = new DBConnection();
        public client()
        {
            
            InitializeComponent();
        }
        
        private void getword()
        {
         comboBox1.DataSource=   m.GetWords("SELECT English FROM  tbl_dictionary");
         comboBox1.DisplayMember = "English";
         //comboBox1.ValueMember = "id";
        }

        private void client_Load(object sender, EventArgs e)
        {
            getword();

            TM sa = new TM();
            
          sa.computers_name(cmb_ipaddresses);
            Thread1 = new Thread(new ThreadStart(MethodListening));
            Thread1.Start();
             
        }

        private void comboBox1_Click(object sender, EventArgs e)
        {
            textBox2.AppendText(comboBox1.GetItemText(comboBox1.SelectedItem) + Environment.NewLine);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

       

        private void smpilbout_open_Click(object sender, EventArgs e)
        {

            try
            {
                OpenFileDialog of = new OpenFileDialog();
                of.Filter = "Text File|*.txt";
                of.ShowDialog();
                StreamReader sr = new StreamReader(of.FileName);
                while (sr.Peek() != -1)
                {
                    textBox1.AppendText(sr.ReadLine() + "\n");

                }
                //sw.Write(textBox1.Text);
                sr.Close();

            }
            catch (Exception ex) { }
        }

        private void simp_butt_send_t_Click(object sender, EventArgs e)
        {
           
                
            
            try
            {
                Socket clientSock = new Socket(AddressFamily.InterNetwork, SocketType.Stream,ProtocolType.Tcp);
                byte[] text = Encoding.UTF8.GetBytes(Environment.MachineName + ":" + textBox2.Text + "\n");
                clientSock.Connect(cmb_ipaddresses.Text, 9050);  
                clientSock.Send(text);
                clientSock.Close();
                textBox1.AppendText(Environment.MachineName+":"+textBox2.Text + "\n");
            }
            catch (Exception ex) { }
        }

       

        

        private void simpl_bout_save_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog sf = new SaveFileDialog();
                sf.Filter = "Text File|*.txt";
                sf.ShowDialog();
                StreamWriter sw = new StreamWriter(sf.FileName);
                sw.Write(textBox1.Text);
                sw.Close();
            }
            catch (Exception ex) { }
        }

        private void smpl_butt_clear_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox1.Focus();
        }

        Socket ListenerObject;
        public void MethodListening()
        {
            byte[] Databytes = new Byte[1024];
            IPEndPoint InitIp = new IPEndPoint(IPAddress.Any, 9050);
             ListenerObject = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                ListenerObject.Bind(InitIp);
                ListenerObject.Listen(50);
                while (true)
                {
                    ActiveThread.Reset();
                    ListenerObject.BeginAccept(new AsyncCallback(AcceptCallback), ListenerObject);
                    ActiveThread.WaitOne();
                }
            }
            catch (Exception ex) { }
        }
        public class StateObject
        {

            public Socket WorkSocket = null;
            public const int BufferSize = 1024;
            public byte[] buffer = new byte[BufferSize];
        }
        Socket ListenerObject1, handler;
        public void AcceptCallback(IAsyncResult ar)
        {
            try
            {
                ActiveThread.Set();
                ListenerObject1 = (Socket)ar.AsyncState;
                handler = ListenerObject.EndAccept(ar);
                StateObject state = new StateObject();
                state.WorkSocket = handler; handler.BeginReceive(state.buffer, 0,
                StateObject.BufferSize, 0, new AsyncCallback(ReadCallback), state); flag = 0;
            }
            catch (Exception ex) { };
        }
        public void ReadCallback(IAsyncResult ar)
        {
            int fileNameLen = 1; String content = String.Empty; StateObject state =
            (StateObject)ar.AsyncState; Socket handler = state.WorkSocket; int bytesRead =
            handler.EndReceive(ar);
            if (bytesRead > 0)
            {
               try 
               {
                GetData = Encoding.UTF8.GetString(state.buffer, 0, bytesRead);
                Invoke(new MyDelegate(LabelWriter));
               }
               catch (Exception ex) { };
            }

        }
        public void LabelWriter()
        {
          textBox1.AppendText(GetData);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

         
        private void simpleButton2_Click(object sender, EventArgs e)
        {
            x.SpeakAsync(textBox1.Text);
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            textBox2.Focus();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void client_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }

        private void simpleButton3_Click(object sender, EventArgs e)
        {
            try
            {
                
                    Socket clientSock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    byte[] text = Encoding.UTF8.GetBytes("aaa");
                    clientSock.Connect(cmb_ipaddresses.Text, 2000);
                    clientSock.Send(text);
                    clientSock.Close();
                   

            }
            catch (Exception ex) { }
        }

        private void client_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                Thread1.Abort();
                ListenerObject.Close();
                ListenerObject1.Close();
                handler.Close();
            }
            catch (Exception ex) { };
        }

      

         
    }
}
    
